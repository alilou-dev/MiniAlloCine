<?php
require_once '../common/CommonComponents.php';
require_once '../common/AuthenticationService.php';
require_once './controller/RealisateursController.php';
require_once './model/DatabaseIndividusRepository.php';

$repo = new DatabaseIndividusRepository();

$realisateurController = new RealisateursController(new AuthenticationService(), new DatabaseIndividusRepository());
$realisateurHtml = $realisateurController->viewAction();
CommonComponents::render($realisateurHtml);