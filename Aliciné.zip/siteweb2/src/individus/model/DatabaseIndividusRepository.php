<?php
require_once __DIR__ . '/../../common/DatabaseClient.php';

class DatabaseIndividusRepository {

    private $database;

    public function __construct()
    {
      $this->database = DatabaseClient::getDatabase();
    }

    public function getAllRealisateurs(){
      $request = $this->database->prepare('SELECT * FROM individus WHERE statut = 1');
      $request->execute();
      $realisateurs = $request->fetchAll(PDO::FETCH_OBJ);
      return $realisateurs;
  }



    public function getAllActeurs(){
      $request = $this->database->prepare('SELECT * FROM individus WHERE statut = 2');
      $request->execute();
      $acteurs = $request->fetchAll(PDO::FETCH_OBJ);
      return $acteurs;
  } 


    public function getPostRealisateurOrActeurById($id){
      $request = $this->database->prepare('SELECT * FROM individus WHERE ID = :id');
      $request->execute(['id'=>$id]);
      $individu = $request->fetch(PDO::FETCH_OBJ);
      return $individu;
  }


}    