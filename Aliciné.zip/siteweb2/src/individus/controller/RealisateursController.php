<?php
require_once __DIR__ . '/../view/viewRealisateur/buildRealisateursView.php';
require_once __DIR__ . '/../view/viewRealisateur/buildPostRealisateurView.php';
require_once __DIR__ . '/../model/DatabaseIndividusRepository.php';

class RealisateursController
{
  private $authenticationService;
  private $realisateurRepository;

  public function __construct(AuthenticationService $authenticationService, DatabaseIndividusRepository $realisateurRepository)
  {
    $this->authenticationService = $authenticationService;
    $this->realisateurRepository = $realisateurRepository;
  }

  public function viewAction(): string {
    if (!$this->authenticationService->isUserConnected()) {
      $this->redirectToLogin();
    }
    $realisateurs = $this->realisateurRepository->getAllRealisateurs();
    return buildRealisateursView($realisateurs);
  }

  public function viewPostAction(): string {
    if (!$this->authenticationService->isUserConnected()) {
      $this->redirectToLogin();
    }
    $realisateur = $this->realisateurRepository->getPostRealisateurOrActeurById($_GET['id']);
    return buildPostRealisateurView($realisateur);
  }
  private function redirectToLogin(): void {
    header('Location: ../user/login.php');
  }
}