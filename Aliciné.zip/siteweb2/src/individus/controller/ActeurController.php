<?php
require_once __DIR__ . '/../view/viewActeurs/buildActeursView.php';
require_once __DIR__ . '/../view/viewActeurs/buildPostActeurView.php';
require_once __DIR__ . '/../model/DatabaseIndividusRepository.php';

class ActeurController
{
  private $authenticationService;
  private $acteurRepository;

  public function __construct(AuthenticationService $authenticationService, DatabaseIndividusRepository $acteurRepository)
  {
    $this->authenticationService = $authenticationService;
    $this->acteurRepository = $acteurRepository;
  }

  public function viewAction(): string {
    if (!$this->authenticationService->isUserConnected()) {
      $this->redirectToLogin();
    }
    $acteurs = $this->acteurRepository->getAllActeurs();
    return buildActeursView($acteurs);
  }

  public function viewPostAction() :string {

    if (!$this->authenticationService->isUserConnected()) {
      $this->redirectToLogin();
    }
    $acteur = $this->acteurRepository->getPostRealisateurOrActeurById($_GET['id']);
    return buildPostActeurView($acteur);
  }


  private function redirectToLogin(): void {
    header('Location: ../user/login.php');
  }
}
