<?php
require_once __DIR__ . '/../common/CommonComponents.php';
require_once __DIR__ . '/../common/AuthenticationService.php';
require_once __DIR__ . '/./controller/ActeurController.php';
require_once __DIR__ . '/./model/DatabaseIndividusRepository.php';

$repo = new DatabaseIndividusRepository();

$postActeurController = new ActeurController(new AuthenticationService(), new DatabaseIndividusRepository());
$postActeurHtml = $postActeurController->viewPostAction();
CommonComponents::render($postActeurHtml);