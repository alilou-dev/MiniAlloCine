<?php

function buildRealisateursView($realisateurs): string
{
  $realisateursCards = realisateurCards($realisateurs);
  
  return <<<HTML
    <div class="row">
      $realisateursCards
    </div>
HTML;
}

function realisateurCards($realisateurs) {
  $cards = '';
  foreach($realisateurs as $realisateur) {
    $cards .= <<<HTML
    <div class="col-sm-3 mb-2">
      <div class="card">
      <img class="card-img-bottom" height="380" src="{$realisateur->url_image}" alt="Card image">
        <div class="card-body">
          <h4 class="card-title">{$realisateur->nom}</h4>
          <h4 class="card-title">{$realisateur->prenom}</h4>
          <h5>
          <small> <strong> d'origine </strong> : {$realisateur->nationalite} <br></small>
          </h5>
          <h5>
          <small> <strong> Age </strong> : {$realisateur->age}</small>
          </h5>
          <p class="card-text"></p>
          <a href="../individus/postRealisateur.php?id={$realisateur->ID}" class="btn btn-primary">plus</a>
        </div>
      </div>
    </div>
HTML;
  }
  return $cards;
}