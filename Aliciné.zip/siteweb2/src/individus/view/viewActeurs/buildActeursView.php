<?php

function buildActeursView($acteurs): string
{
  $acteursCards = acteurCards($acteurs);
  
  return <<<HTML
    <div class="row">
      $acteursCards
    </div>
HTML;
}

function acteurCards($acteurs) {
  $cards = '';
  foreach($acteurs as $acteur) {
    $cards .= <<<HTML
    <div class="col-sm-3 mb-3">
      <div class="card">
      <img class="card-img-bottom" height="380" src="{$acteur->url_image}" alt="Card image">
        <div class="card-body">
          <h4 class="card-title">{$acteur->nom}</h4>
          <h4 class="card-title">{$acteur->prenom}</h4>
          <small> <strong> d'origine </strong> : {$acteur->nationalite} <br></small>
          <small> <strong> Age </strong> : {$acteur->age}</small>
          <p class="card-text"></p>
          <a href="../individus/postActeur.php?id={$acteur->ID}" class="btn btn-primary">plus</a>
        </div>
      </div>
    </div>
HTML;
  }
  return $cards;
}