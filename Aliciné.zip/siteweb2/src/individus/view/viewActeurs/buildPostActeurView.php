<?php

function buildPostActeurView($acteur): string
{
  $postActeurCards = postActeurCards($acteur);
  
  return <<<HTML
    <div class="row">
      <div class="col-sm-4">
        <img class="card-img-bottom" height='auto' src="{$acteur->url_image}" alt="Card image">
      </div>
      <div class="col-sm-8">
        <h2>{$acteur->nom} {$acteur->prenom} </h2>
        <h5>
          <small> <strong> d'origine </strong> : {$acteur->nationalite} <br></small>
        </h5>
        <h5>  
          <small> <strong> Age </strong> : {$acteur->age}</small>
        </h5>
        <p>
          <strong>Présentation:</strong> <br>
          {$acteur->presentation}
        </p>
      </div>
    </div>
HTML;
}

function postActeurCards($acteur) {
  $cards = '';

    $cards .= <<<HTML
    <div class="col-sm-3 mb-3">
      <div class="card">
      <img class="card-img-bottom" height="380" src="{$acteur->url_image}" alt="Card image">
        <div class="card-body">
          <h4 class="card-title">{$acteur->nom}</h4>
          <h4 class="card-title">{$acteur->prenom}</h4>
          <small> <strong> d'origine </strong> : {$acteur->nationalite} <br></small>
          <small> <strong> Age </strong> : {$acteur->age}</small>
          <p class="card-text"></p>
          <a href="#" class="btn btn-primary">plus</a>
        </div>
      </div>
    </div>
HTML;
  return $cards;
}