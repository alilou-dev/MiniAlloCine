<?php
require_once '../common/CommonComponents.php';
require_once '../common/AuthenticationService.php';
require_once './controller/FilmController.php';
require_once './model/DatabaseFilmRepository.php';

$repo = new DatabaseFilmRepository();

$filmController = new FilmController(new AuthenticationService(), new DatabaseFilmRepository());
$filmHtml = $filmController->viewAction();
CommonComponents::render($filmHtml);

function debug($val) {
    echo "<pre>";
    var_dump($val);
    echo "</pre>";
}