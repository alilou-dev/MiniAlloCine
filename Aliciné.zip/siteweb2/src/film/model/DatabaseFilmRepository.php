<?php
require_once '../common/DatabaseClient.php';

class DatabaseFilmRepository {

    private $database;

    public function __construct()
    {
      $this->database = DatabaseClient::getDatabase();
    }

    public function getAllFilms()
    {
        $request = $this->database->prepare('SELECT f.ID, f.nom , f.annee, f.duree, f.id_realisateur, f.description description, f.url_image, i.nom nom_realisateur , i.prenom prenom_realisateur, c.nom categorie FROM films f INNER JOIN individus i ON f.id_realisateur = i.ID INNER JOIN categories c ON f.id_categorie = c.ID');
        $request->execute();
        $films = $request->fetchAll(PDO::FETCH_OBJ);
        return $films;

    }
  /*
    public function checkFilmExistence(string $nom): bool
    {
        $request = $this->database->prepare('SELECT count(*) AS numberOfFilms FROM films WHERE nom = :nom');
        $request->execute(['nom' => $nom]);
        return $request->fetch(PDO::FETCH_OBJ)->numberOfFilms > 0;
    }

    public function getFilmById(int $id)
    {
        $request = $this->database->prepare('SELECT nom, annee, duree, id_categorie, id_realisateur, url_image FROM films WHERE id = :id');
        $request->execute(['id'=>$id]);
        $film = $request->fetch(PDO::FETCH_OBJ);
        return $film;
    }

    
    public function getAllFilmByYear(int $annee)
    {
        $request = $this->database->prepare('SELECT nom,annee FROM films WHERE annee = :annee');
        $request->execute(['annee'=>$annee]);
        $films = $request->fetchAll(PDO::FETCH_OBJ);
        return $films;
    }
    
    public function getCategorieFilm(int $id)
    {
        $request = $this->database->prepare('SELECT c.nom FROM categories c INNER JOIN films f ON c.ID = f.id_categorie WHERE f.id = :id');
        $request->execute(['id'=>$id]);
        $categorie = $request->fetch(PDO::FETCH_OBJ);
        return $categorie;
    }
    */
    public function getRealisateurById(int $id)
    {
        $request = $this->database->prepare('SELECT * FROM individus WHERE ID = :id');      
        $request->execute(['id'=>$id]);
        $realisateur = $request->fetch();
        return $realisateur;
    }

    public function getThreeLastFilms()
    {
        $request = $this->database->prepare('SELECT nom, annee, duree, url_image FROM films ORDER BY ID desc LIMIT 3');
        $request->execute();
        $films = $request->fetchAll(PDO::FETCH_OBJ);
        return $films;
    }

    public function get10FilmsByName($name) {
        $lowerCasedName = strtolower($name);
        $request = $this->database->prepare("SELECT ID, nom FROM films WHERE LOWER(nom) LIKE ? ORDER BY nom desc LIMIT 10");
        $request->execute(["%$lowerCasedName%"]);
        $films = $request->fetchAll(PDO::FETCH_OBJ);
        return $films;
    }

    public function getAllRealisateurs(){
        $request = $this->database->prepare('SELECT * FROM individus WHERE statut = 1');
        $request->execute();
        $realisateurs = $request->fetchAll(PDO::FETCH_OBJ);
        return $realisateurs;

    }

    public function getFilmById(int $id)
    {
        $request = $this->database->prepare('SELECT f.nom nom, f.annee annee, f.duree duree, f.id_realisateur, f.description_complete description_complete, f.description description , f.url_image , i.nom nom_realisateur, i.prenom prenom_realisateur, c.nom categorie FROM films f INNER JOIN individus i ON f.id_realisateur = i.ID INNER JOIN categories c ON f.id_categorie = c.ID WHERE f.ID = :id');
        $request->execute(['id'=>$id]);
        $film = $request->fetch(PDO::FETCH_OBJ);
        return $film;
    }


}
