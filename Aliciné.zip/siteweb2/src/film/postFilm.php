<?php
require_once '../common/CommonComponents.php';
require_once '../common/AuthenticationService.php';
require_once './controller/FilmController.php';
require_once './model/DatabaseFilmRepository.php';

$repo = new DatabaseFilmRepository();

$postFilmController = new FilmController(new AuthenticationService(), new DatabaseFilmRepository());
$postFilmHtml = $postFilmController->viewPostAction();
CommonComponents::render($postFilmHtml);
function debug($val){
    echo "<pre>";
    print_r($val);
    echo "</pre>";
}
?>