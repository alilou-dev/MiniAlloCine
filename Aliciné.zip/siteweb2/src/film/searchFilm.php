<?php
require_once './controller/api.FilmController.php';
require_once './model/DatabaseFilmRepository.php';

$repo = new DatabaseFilmRepository();

$search = htmlspecialchars($_GET['search']);

$apiFilmController = new ApiFilmController(new DatabaseFilmRepository());
echo $apiFilmController->findFilmsByNameAction($search);
