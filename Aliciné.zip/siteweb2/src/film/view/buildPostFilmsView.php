<?php

function buildPostFilmsView($film): string
{
  $postFilmCards = postFilmCards($film);
  
  return <<<HTML
    <div class="row">
      <div class="col-sm-4">
        <img class="card-img-bottom" height='auto' src="{$film->url_image}" alt="Card image">
      </div>
      <div class="col-sm-8">
        <h2>{$film->nom}</h2>
        <h5><small>{$film->categorie}</small></h5>
        <h5> 
          réaliser par 
          <a class="btn btn-link" 
            href="../individus/postRealisateur.php?id={$film->id_realisateur}" 
            role="button">
            {$film->nom_realisateur} {$film->prenom_realisateur}
          </a>
        </h5>
          
        <h5 class="mb-5">sorti en {$film->annee}</h5>

        <p>
          <strong>Synopsis:</strong> <br>
          {$film->description_complete}
        </p>
      </div>
    </div>
HTML;
}

function postFilmCards($film) {
  $cards = '';
    $cards .= <<<HTML
    <div color class="col-sm-3 mb-3">
      <div class="card">
      <img class="card-img-bottom" height='300' src="{$film->url_image}" alt="Card image">
        <div class="card-body">
          <h5 class="card-title">{$film->nom}</h5>
          <h6> réaliser par <a class="btn btn-link" href="../../individus/postRealisateur.php?id={$film->id_realisateur}" role="button">{$film->nom_realisateur} {$film->prenom_realisateur}</a></h6>
          <small>sorti en {$film->annee}</small>
          <p class="card-text">{$film->description_complete}</p>
          <a href="#" class="btn btn-primary">fiche</a>
        </div>
      </div>
    </div>
HTML;
  return $cards;
}