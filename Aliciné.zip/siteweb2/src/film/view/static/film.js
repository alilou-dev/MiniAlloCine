$(function () {
    
    var origin = location.href.split('/src')[0];
    
    $('#search-films').keyup(function () {
        $('#result-search').html('');
        var search = $(this).val();
        if (search !== "") {
            $.get({
                url: `${origin}/src/film/searchFilm.php?search=${search}`,
                success: function (data) {
                    var films = JSON.parse(data);
                    
                    if (films.length > 0) {
                        var filmsLinks = films.map(film => `<a href="${origin}/src/film/postFilm.php?id=${film.ID}" class="search-result list-group-item list-group-item-action small">${film.nom}</a>`)
                        $('#result-search').html(filmsLinks.join(''));
                    } else {
                        $('#result-search').html('<li class="search-result list-group-item small">Aucun résultat</li>');
                    }

                }
            });
        }

    });

    $('#search-films').focus(function() {
        $('#result-search').removeClass('d-none');
    });

    $('body').click(function(e) {
        if (e.target 
            && e.target.id !== 'search-films' 
            && !e.target.classList.value.includes('search-result')) {
            $('#result-search').addClass('d-none');
        }
    });
});