<?php

function buildFilmsView($films,$threeLastFilms): string
{
  $filmCards = filmCards($films);
  $carousel = carousel($threeLastFilms);
  
  return <<<HTML
    <div class="row mb-5">
      <div class="col">
        $carousel
      </div>
    </div>
    <div class="row">
      $filmCards
    </div>
HTML;
}

function carousel($threeLastFilms) {
  $carouselInterval =5000;
  return <<<HTML
    <div id="film-carousel" 
        class="carousel slide" 
        data-interval="$carouselInterval"
        style="background: rgb(82 82 82 / 70%);"
        data-ride="carousel">

      <!-- Indicators -->
      <ul class="carousel-indicators">
        <li data-target="#film-carousel" data-slide-to="0" class="active"></li>
        <li data-target="#film-carousel" data-slide-to="1"></li>
        <li data-target="#film-carousel" data-slide-to="2"></li>
      </ul>

      <!-- The slideshow -->
      <div class="carousel-inner">
        <div class="carousel-item active text-center">
          <img src="{$threeLastFilms[0]->url_image}" height="300" alt="image film">
        </div>
        <div class="carousel-item text-center">
        <img src="{$threeLastFilms[1]->url_image}" height="300" alt="image film">
        </div>
        <div class="carousel-item text-center">
        <img src="{$threeLastFilms[2]->url_image}" height="300" alt="image film">
        </div>
      </div>

      <!-- Left and right controls -->
      <a class="carousel-control-prev" href="#film-carousel" data-slide="prev">
        <span class="carousel-control-prev-icon"></span>
      </a>
      <a class="carousel-control-next" href="#film-carousel" data-slide="next">
        <span class="carousel-control-next-icon"></span>
      </a>

    </div>
HTML;
}

function filmCards($films) {
  $cards = '';
  foreach($films as $film) {
    $cards .= <<<HTML
    <div color class="col-sm-3 mb-3">
      <div class="card">
      <img class="card-img-bottom" height='300' src="{$film->url_image}" alt="Card image">
        <div class="card-body">
          <h5 class="card-title">{$film->nom}</h5>
          <h6> réaliser par <a class="btn btn-link" href="../../individus/postRealisateur.php?id={$film->id_realisateur}" role="button">{$film->nom_realisateur} {$film->prenom_realisateur}</a></h6>
          <small>sorti en {$film->annee}</small>
          <small>categorie :  {$film->categorie}</small>
          <p class="card-text">{$film->description}</p>
          <a href="../film/postFilm.php?id={$film->ID}" class="btn btn-primary">plus</a>
        </div>
      </div>
    </div>
HTML;
  }
  return $cards;
}