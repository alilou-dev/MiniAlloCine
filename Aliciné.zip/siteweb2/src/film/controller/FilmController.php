<?php
require_once './view/buildFilmsView.php';
require_once './view/buildPostFilmsView.php';
require_once './model/DatabaseFilmRepository.php';

class FilmController
{
  private $authenticationService;
  private $filmRepository;

  public function __construct(AuthenticationService $authenticationService, DatabaseFilmRepository $filmRepository)
  {
    $this->authenticationService = $authenticationService;
    $this->filmRepository = $filmRepository;
  }

  public function viewAction(): string {
    if (!$this->authenticationService->isUserConnected()) {
      $this->redirectToLogin();
    }

    $films = $this->filmRepository->getAllFilms();
    $threeLastFilms = $this->filmRepository->getThreeLastFilms();
    return buildFilmsView($films,$threeLastFilms);
  }

  public function viewPostAction(): string {
    if (!$this->authenticationService->isUserConnected()) {
      $this->redirectToLogin();
    }

    $film = $this->filmRepository->getFilmById($_GET['id']);
    return buildPostFilmsView($film);
  }

  private function redirectToLogin(): void {
    header('Location: ../../src/user/login.php');
  }
}
