<?php
require_once './model/DatabaseFilmRepository.php';

class ApiFilmController
{
  private $filmRepository;

  public function __construct(DatabaseFilmRepository $filmRepository)
  {
    $this->filmRepository = $filmRepository;
  }

  public function findFilmsByNameAction($name): string {
    $films = $this->filmRepository->get10FilmsByName($name);

    return json_encode($films, JSON_UNESCAPED_UNICODE);
  }
}
