<?php

echo'bonjour';
echo'ok';

?>