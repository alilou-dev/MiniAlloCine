<?php
require_once __DIR__ . '/../../common/DatabaseClient.php';
require_once __DIR__ . '/UserRepository.php';
require_once __DIR__ . '/UserBuilder.php';
require_once __DIR__ . '/User.php';

class DatabaseUserRepository implements UserRepository
{
  private $database;

  public function __construct()
  {
    $this->database = DatabaseClient::getDatabase();
  }

  public function checkUserExistence(string $username, string $password): bool
  {
    $request = $this->database->prepare('SELECT password FROM users WHERE username = :username');
    $request->execute([
      'username' => $username
    ]);

    $user = $request->fetch(PDO::FETCH_OBJ);

    if (!$user) {
      return false;
    }

    return password_verify($password,$user->password);
  }

  public function getUserByUsername(string $username): ?User
  {
    $request = $this->database->prepare('SELECT firstname, lastname, username FROM users WHERE username = :username');
    $request->execute(['username' => $username]);
    $user = $request->fetch(PDO::FETCH_OBJ);

    if (!$user) {
      return null;
    }

    $userBuilder = new UserBuilder();
    return $userBuilder
      ->withFirstName($user->firstname)
      ->withLastName($user->lastname)
      ->withUsername($user->username)
      ->build();
  }

  public function createUser($firstName, $lastName, $username, $password): void
  {
    $request = $this->database->prepare('INSERT INTO users(firstname, lastname, username, password) VALUES (:firstname, :lastname, :username, :password)');
    $password_crypte = password_hash($password, PASSWORD_BCRYPT);

    $request->execute([
      'firstname' => $firstName,
      'lastname' => $lastName,
      'username' => $username,
      'password' => $password_crypte
    ]);
  }
 
}
