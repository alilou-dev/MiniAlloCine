<?php
class DatabaseClient {
  private static $instance = null;
  private $database;
  private $username = 'root';
  private $password = '';

  private function __construct()
  {
    $this->database = new PDO('mysql:dbname=alicine;host=localhost',
      $this->username,
      $this->password,
      [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ]
    );
  }

  public static function getDatabase() {
    if(is_null(self::$instance)) {
      self::$instance = new DatabaseClient();
    }
    return self::$instance->database;
  }
}
